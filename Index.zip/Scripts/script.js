let work = document.getElementById("work");
let tooltip = document.getElementById("tooltiptext");
var x = 0;
var y = 0;

window.addEventListener("mousedown", function (e) {
	x = e.x;
	y = e.y;
	tooltip.style.left = `${x}px`;
	tooltip.style.top = `${y}px`
});